package logica;
public abstract class Efecto {
	
	public abstract  void accion(Jugador jugador);
}
