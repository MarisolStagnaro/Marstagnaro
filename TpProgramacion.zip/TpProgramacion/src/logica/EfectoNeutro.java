package logica;
public class EfectoNeutro extends Efecto {

	@Override
	public void accion(Jugador jugador) {

		
	}

}
