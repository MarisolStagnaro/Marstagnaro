package logica;
public abstract class RandomGenerator {

	public abstract int obtenerAleatorioMenorQue(int maximo);
}